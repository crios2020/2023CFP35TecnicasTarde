public class Laboratorio {
    public static void main(String[] args) {
        //Laboratorio
        //Usando la estructura for imprimir la siguiente figura
        //    *
        //   ***
        //  *****
        // *******
        //  *****
        //   ***
        //    *
    }
}
