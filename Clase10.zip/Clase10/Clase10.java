public class Clase10{
    public static void main(String[] args) {
        
        //Estructura while
        int x=1;
        System.out.println("-- Inicio Estructura While --");
        while(x<=10){
            System.out.println(x);
            x++;
        }
        System.out.println("-- Fin Estructura While --");
        System.out.println(x);

        //Estructura do while
        x=1;
        System.out.println("-- Inicio Estructura do While --");
        do{
            System.out.println(x);
            x++;
        }while(x<=10);
        System.out.println("-- Fin Estructura do While --");
        System.out.println(x);

        //Estructura for
        System.out.println("-- Inicio Estructura For --");
        for(int a=1; a<=10; a++){
            System.out.println(a);
        }
        System.out.println("-- Fin Estructura For");
        System.out.println("-- Inicio Estructura For --");
        for(int a=1; a<=10; a++){
            System.out.println(a);
        }
        System.out.println("-- Fin Estructura For");
        // System.out.println(a); //error variable a esta fuera scope(alcance)


    }
}