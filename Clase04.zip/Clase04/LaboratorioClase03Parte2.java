public class LaboratorioClase03Parte2 {
    public static void main(String[] args) {
        //Ejercicio 9 - Operadores Lógicos
        System.out.println("Ejercicio 9");
        System.out.println("A");
        boolean n1 = true;
        boolean n2 = false;
        boolean n3 = !n1;
        boolean n4 = !n2;
        System.out.println(n3);
        System.out.println(n4);
        System.out.println("B");
        n3 = n1 & n2;

        n4 = n1 | n2;
        System.out.println(n3);
        System.out.println(n4);
        System.out.println("C");
        n3 = !(n1 & n2);
        n4 = !(n1 | n2);
        System.out.println(n3);
        System.out.println(n4);
        System.out.println("D");
        n3 = !n1 & n2;
        n4 = !n1 | n2;
        System.out.println(n3);
        System.out.println(n4);
        System.out.println("E");

        /*
            Tabla para completar:

                        n1          n2          n3
            A
            B
            C
            D
            E

        */
        
        
    }
}
