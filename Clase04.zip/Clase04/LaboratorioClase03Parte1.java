public class LaboratorioClase03Parte1{
    public static void main(String[] args) {
        // Ejercicio 1 - Asignación básica
        // Analice el código a continuación y complete la tabla correspondiente. Luego realice la codificación
        // para confirmar que ha completado la tabla correctamente.
        System.out.println("Ejercicio 1 - Asignación básica");
        System.out.println("A");
        int x = 10;
        int y = 20;
        System.out.println(x);
        System.out.println(y);
        System.out.println("B");
        x = x + 5;
        y = y + 10;
        System.out.println(x);
        System.out.println(y);
        System.out.println("C");
        x = x - 5;
        y = y - 10;
        System.out.println(x);
        System.out.println(y);
        System.out.println("D");
        x = x * 3;
        y = y * 5;
        System.out.println(x);
        System.out.println(y);
        System.out.println("E");
        x = x / 2;
        y = y / 4;
        System.out.println(x);
        System.out.println(y);
        
        /*
            Tabla para completar:

                        X           Y
            A           10          20
            B           15          30
            C
            D
            E

        */
       
        // Ejercicio 2 - Asignación compacta
        // Analice el código a continuación y complete la tabla correspondiente. Luego realice la codificación
        // para confirmar que ha completado la tabla correctamente.
        System.out.println("Ejercicio 2 - Asignación compacta");
        System.out.println("A");
        x = 10;
        y = 20;
        System.out.println(x);

        System.out.println(y);
        System.out.println("B");
        x += 5;
        y -= 15;
        System.out.println(x);
        System.out.println(y);
        System.out.println("C");
        x++;
        y--;
        System.out.println(x);
        System.out.println(y);
        System.out.println("D");
        x *= 4;
        y *= -3;
        System.out.println(x);
        System.out.println(y);
        System.out.println("E");
        x /= 2;
        y /= 4;
        System.out.println(x);
        System.out.println(y);
        
        /*
            Tabla para completar:

                        X           Y
            A
            B
            C
            D
            E

        */

        // Ejercicio 3 - Operadores aritméticos
        System.out.println("Ejercicio 3 - Operadores aritméticos");
        System.out.println("A");
        x = 10;
        y = 20;
        System.out.println(x);
        System.out.println(y);
        System.out.println("B");
        x = x + y;
        y = y + x;
        System.out.println(x);
        System.out.println(y);
        System.out.println("C");
        x= x - y;
        y= y - x;
        System.out.println(x);
        System.out.println(y);
        System.out.println("D");
        x=x * y;
        y=x * x;
        System.out.println(x);
        System.out.println(y);
        System.out.println("E");
        x= y / x;
        y= x / y;
        System.out.println(x);
        System.out.println(y);
        
        /*
            Tabla para completar:

                        X           Y
            A
            B
            C
            D
            E

        */

        //Ejercicio 4- Operadores aritméticos con asignación compacta
        System.out.println("Ejercicio 4- Operadores aritméticos con asignación compacta");
        System.out.println("A");
        x = 5;
        y = 10;
        System.out.println(x);
        System.out.println(y);
        System.out.println("B");
        x += y;
        y += x;
        System.out.println(x);
        System.out.println(y);
        System.out.println("C");
        x -= y;
        y -= x;
        System.out.println(x);
        System.out.println(y);
        System.out.println("D");
        x *= y;
        y *= x;
        System.out.println(x);
        System.out.println(y);
        System.out.println("E");
        x /= y;
        y /= y;
        System.out.println(x);
        System.out.println(y);

        /*
            Tabla para completar:

                        X           Y
            A
            B
            C
            D
            E

        */



        // Ejercicio 5- Operadores Aritméticos con asignación múltiple (suma y resta)
        System.out.println("Ejercicio 5- Operadores Aritméticos con asignación múltiple (suma y resta)");
        System.out.println("A");
        x = 5;
        y = 10;
        int suma = 0;
        int resta = 0;
        System.out.println(x);
        System.out.println(y);
        System.out.println(suma);
        System.out.println(resta);
        System.out.println("B");
        suma = x + y;
        resta = x - y;
        System.out.println(x);
        System.out.println(y);
        System.out.println("C");
        suma = x + x;
        resta = y - y;
        System.out.println(x);
        System.out.println(y);
        System.out.println("D");
        suma = x + y + x;
        resta = x - x - 20;
        System.out.println(x);
        System.out.println(y);
        System.out.println("E");
        suma = y + x + x;
        resta = -x - y -y ;
        System.out.println(x);
        System.out.println(y);
  
        /*
            Tabla para completar:

                        X           Y           suma        resta
            A
            B
            C
            D
            E

        */


        //Ejercicio 6- Operadores Aritméticos con asignación múltiple (producto y división)
        System.out.println("Ejercicio 6");
        System.out.println("A");
        x = 5;
        y = 10;
        int multi = 1;
        int division = 1;
        System.out.println(x);
        System.out.println(y);
        System.out.println(multi);
        System.out.println(division);
        System.out.println("B");
        multi = x * y;
        division = x / y;
        System.out.println(multi);
        System.out.println(division);
        System.out.println("C");
        multi = x * x;
        division = y / y;
        System.out.println(multi);
        System.out.println(division);
        System.out.println("D");
        multi = x * y * x;
        division = y / x;
        System.out.println(multi);
        System.out.println(division);
        System.out.println("E");
        multi= x * (-y);
        division= y / (-x);
        System.out.println(multi);
        System.out.println(division);

        /*
            Tabla para completar:

                        X           Y           multi       division
            A
            B
            C
            D
            E

        */

        //Ejercicio 7- Operador Resto
        System.out.println("Ejercicio 7");
        System.out.println("A");
        int n1 = 20;
        int n2 = 2;
        int n3 = n1 % n2;
        System.out.println(n3);
        System.out.println("B");
        n1 = 15;
        n2 = 2;
        n3 = n1 % n2;
        System.out.println(n3);
        System.out.println("C");
        n1 = 3;
        n2 = 20;
        n3 = n2 % n1;
        System.out.println(n3);
        System.out.println("D");
        n1 = 3;
        n2 = 15;
        n3 = n2 % n1;
        System.out.println(n3);
       
        /*
            Tabla para completar:

                        n1          n2          n3
            A
            B
            C
            D
            

        */


        // Ejercicio 8 - Cadenas de Caracteres
        System.out.println("Ejercicio 8");
        System.out.println("A");
        String palabra_1 = "Hola";
        String palabra_2 = "Mundo";
        String frase = "";
        System.out.println(palabra_1);
        System.out.println(palabra_2);
        System.out.println(frase);
        System.out.println("B");
        frase = palabra_1 + palabra_2;
        System.out.println(palabra_1);
        System.out.println(palabra_2);
        System.out.println(frase);
        System.out.println("C");
        frase = palabra_1 + " \t " + palabra_2;
        System.out.println(palabra_1);
        System.out.println(palabra_2);
        System.out.println(frase);
        System.out.println("D");
        frase = palabra_1 + " \n " + palabra_2;
        System.out.println(palabra_1);
        System.out.println(palabra_2);
        System.out.println(frase);
        System.out.println("E");
        frase = palabra_1 + " \n \t " + palabra_2;
        System.out.println(palabra_1);
        System.out.println(palabra_2);
        System.out.println(frase);
        
        /*
            Tabla para completar:

                        palabra1            palabra2        frase
            A
            B
            C
            D
            E

        */

       
    }
}