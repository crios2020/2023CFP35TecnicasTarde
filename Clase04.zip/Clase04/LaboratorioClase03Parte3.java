public class LaboratorioClase03Parte3 {
    public static void main(String[] args) {
        
        //RESOLVER LOS SIGUIENTES ENUNCIADOS, DESARROLLANDO EL CÓDIGO
        
        //Ejercicio 10
        System.out.println("Ejercicio 10");
        // Dados n1=5, n2=10 y n3=20. Informar:
        // a) n1+n2
        // b) n3-n1
        // c) n1*n3
        // d) n3/n2

        //Ejemplo:
        int n1=5;
        int n2=10;
        System.out.println(n1+n2);

        //Ejercicio 11
        System.out.println("Ejercicio 11");
        // Dados n1=10, n2=20 y n3=30. Informar :
        // a) El total
        // b) El promedio
        // c) El resto entre n2 y n1

        // Ejercicio 12
        System.out.println("Ejercicio 12");
        // Dados n1=true, n2=false y n3=true. Informar :
        // a) n1 ^ n2
        // b) (n1 & !n2) | n3
        // c) (n1 | n2) & !n3

        // Ejercicio 13
        System.out.println("Ejercicio 13");
        // Declarar dos variables n1=5 y n2=10.
        // Utilizando concatenación entre las variables y los literales, mostrar en pantalla la siguiente
        // expresión:
        // n1 es igual a 5,n2 es igual a 10 y n1 más n2 es igual a 15.

        // Ejercicio 14 - Uso de constantes
        System.out.println("Ejercicio 14");
        // Haciendo uso de la constante IVA=21,calcular el precio con iva de los siguientes productos e
        // informar:
        // a) remera:59.90$
        // b) pantalón:99.90$
        // c) campera:149.90$

    }
}
