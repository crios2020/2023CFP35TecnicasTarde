public class LaboratorioAdicionalWhile {
    public static void main(String[] args) {
        // Ejercicio 1
        // Imprimir los números del 1 al 10 uno abajo del otro.
        System.out.println("Ejercicio 1");
        int x=1;
        while(x<=10){
            System.out.println(x);
            x++;
        }
        // Ejercicio 2
        // Imprimir los números del 1 al 10 salteando de a 2 uno abajo del otro.
        
        // Ejercicio 3
        // Imprimir los números del 10 al 1 uno abajo del otro.
        
        // Ejercicio 4
        // Imprimir los números del 1 al 10 sin imprimir números 2,5 y 9 uno abajo del otro
        // Requisito: se necesita tener conocimiento del operador AND (&&) y del operador NOT (!=).
        
        // Ejercicio 5
        // Imprimir los números del 1 al 30 sin imprimir números entre el 10 y el 20 uno abajo del otro
        // Requisito: se necesita tener conocimientos del operador OR (||).
        
        // Ejercicio 6
        // Imprimir la suma de los números del 1 al 10.
        
        // Ejercicio 7
        // Imprimir la suma de los números pares del 1 al 25
        // Requisito: se necesita tener conocimientos del operador RESTO (%).
        
        // Ejercicio 8
        // Imprimir la multiplicación de los números impares que se encuentran entre -10 y 10.
    
    }
}
