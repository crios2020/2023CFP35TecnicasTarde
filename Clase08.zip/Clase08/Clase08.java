public class Clase08{
    public static void main(String[] args) {
        //Estructura while

        int a=1;
        System.out.println("-- inicio estructura while --");
        while(a<=10){
            System.out.println(a);
            a++;
        }
        System.out.println("-- fin estructura while --");
        System.out.println(a);


        //Ejemplo de uso de while

        char car=76;
        System.out.println(car);

        car=32;
        while(car<255){
            System.out.println("valor: "+((int)car)+" - caracter: "+car);
            car++;
        }

        //TODO loop infinito

        

    }
}