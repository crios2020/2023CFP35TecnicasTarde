import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;

public class Fecha {
    public static void main(String[] args) {
        //Date date=new Date();                   // JDK 1
        //System.out.println(date);

        //Calendar cal=Calendar.getInstance();        //JDK 1.1
        //System.out.println(cal);

        LocalDateTime ldt=LocalDateTime.now();          //JDK 8
        //System.out.println(ldt);

        int nroDiaMes=ldt.getDayOfMonth();
        int nroDiaSemana=ldt.getDayOfWeek().getValue(); //2         1 lunes .... 7 domingo
        int nroMes=ldt.getMonthValue();                 //8         1 Enero .... 12 Diciembre
        int anio=ldt.getYear();
        String nombreDia="";
        String nombreMes="";

        //System.out.println(nroDiaSemana);
        //System.out.println(nroMes);

        if(nroDiaSemana==1)                 nombreDia="Lunes";
        if(nroDiaSemana==2)                 nombreDia="Martes";
        if(nroDiaSemana==3)                 nombreDia="Miércoles";
        if(nroDiaSemana==4)                 nombreDia="Jueves";
        if(nroDiaSemana==5)                 nombreDia="Viernes";
        if(nroDiaSemana==6)                 nombreDia="Sábado";
        if(nroDiaSemana==7)                 nombreDia="Domingo";

        if(nroMes==1)                       nombreMes="Enero";
        if(nroMes==2)                       nombreMes="Febrero";
        if(nroMes==3)                       nombreMes="Marzo";  
        if(nroMes==4)                       nombreMes="Abril";
        if(nroMes==5)                       nombreMes="Mayo";
        if(nroMes==6)                       nombreMes="Junio";
        if(nroMes==7)                       nombreMes="Julio";
        if(nroMes==8)                       nombreMes="Agosto";
        if(nroMes==9)                       nombreMes="Septiembre";
        if(nroMes==10)                      nombreMes="Octubre";
        if(nroMes==11)                      nombreMes="Noviembre";
        if(nroMes==12)                      nombreMes="Diciembre";

        System.out.println("Hoy es "+nombreDia+" "+nroDiaMes+" de "+nombreMes+" de "+anio);

    }
}
