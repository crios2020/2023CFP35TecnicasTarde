import java.util.Calendar;

public class Ubicacion {
    public static void main(String[] args) {
        Calendar cal=Calendar.getInstance();
        System.out.println(
                                cal
                                    .getTimeZone()
                                    .getID()
                                    .replace("/", " ")
                                    .replace("_", " ")
                        );
    }
}
