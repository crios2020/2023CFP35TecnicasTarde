public class Login {
    public static void main(String[] args) {
        /*
         * Ingresa por consola el String user y el string pass
         * Si el usuario es "root" y el pass="123"  informar "Bienvenido al sistema!"
         * Sino informar "Error en datos de ingreso!"
         */
        System.out.println(Colores.ANSI_GREEN);
        System.out.println("*******************************************************");
        System.out.println("*                  LOGIN DEL SISTEMA                  *");
        System.out.println("*******************************************************");
        System.out.println(Colores.ANSI_CYAN);
        System.out.print("Ingrese su nombre de usuario: ");
        String user=new java.util.Scanner(System.in).nextLine();
        System.out.print("Ingrese su clave: ");
        String pass=new java.util.Scanner(System.in).nextLine();

        //System.out.println(user+"\t"+pass);
        //System.out.println(user=="root");
        //System.out.println(user.equals("root"));
        //System.out.println(user.equalsIgnoreCase("root"));

        if(user.equals("root") && pass.equals("123")){
            System.out.print(Colores.ANSI_GREEN);
            System.out.println("""
                ░░░░░░░░░░░░░░░░░░░░░░█████████
                ░░███████░░░░░░░░░░███▒▒▒▒▒▒▒▒███
                ░░█▒▒▒▒▒▒█░░░░░░░███▒▒▒▒▒▒▒▒▒▒▒▒▒███
                ░░░█▒▒▒▒▒▒█░░░░██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
                ░░░░█▒▒▒▒▒█░░░██▒▒▒▒▒██▒▒▒▒▒▒██▒▒▒▒▒███
                ░░░░░█▒▒▒█░░░█▒▒▒▒▒▒████▒▒▒▒████▒▒▒▒▒▒██
                ░░░█████████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
                ░░░█▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒▒██
                ░██▒▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒██▒▒▒▒▒▒▒▒▒▒██▒▒▒▒██
                ██▒▒▒███████████▒▒▒▒▒██▒▒▒▒▒▒▒▒██▒▒▒▒▒██
                █▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒████████▒▒▒▒▒▒▒██
                ██▒▒▒▒▒▒▒▒▒▒▒▒▒▒█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
                ░█▒▒▒███████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒██
                ░██▒▒▒▒▒▒▒▒▒▒████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒█
                ░░████████████░░░█████████████████
                    """);
            Ubicacion.main(null);
            Fecha.main(null);
            System.out.println("Bienvenido Usuario!");
        } else {
            System.out.print(Colores.ANSI_RED);
            System.out.println("""
                ███████▄▄███████████▄
                ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓▓█░░░░░░░░░░░░░░█
                ▓▓▓▓▓▓███░░░░░░░░░░░░█
                ██████▀░░█░░░░██████▀
                ░░░░░░░░░█░░░░█
                ░░░░░░░░░░█░░░█
                ░░░░░░░░░░░█░░█
                ░░░░░░░░░░░█░░█
                ░░░░░░░░░░░░▀▀
                
                    """);
            System.out.println("Error de Ingreso!");
        }

    }
}
