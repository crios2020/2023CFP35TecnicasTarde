public class Laboratorio {
    public static void main(String[] args) {
        //Laboratorio
        //Usando la estructura for imprimir la siguiente figura
        //    *
        //   ***
        //  *****
        // *******
        //  *****
        //   ***
        //    *

        System.out.println("-- Laboratorio --");
        int cant=7;             //debe ser impar
        int m=cant/2+1;
        for(int x=0; x<=m-1; x++){
            for(int a=1; a<=cant; a++){
                if(a<=m+x && a>=m-x)    System.out.print("*");
                else                    System.out.print(" ");
            }
            System.out.println();
        }
        for(int x=m-2; x>=0; x--){
            for(int a=1; a<=cant; a++){
                if(a<=m+x && a>=m-x)    System.out.print("*");
                else                    System.out.print(" ");
            }
            System.out.println();
        }
    }
}
