import java.text.DecimalFormat;
import java.time.LocalTime;

public class Clase12 {
    public static void main(String[] args) {

        // Estructura while
        int x = 1;
        System.out.println("-- Inicio Estructura While --");
        while (x <= 10) {
            System.out.println(x);
            x++;
        }
        System.out.println("-- Fin Estructura While --");
        System.out.println(x);

        // Estructura do while
        x = 1;
        System.out.println("-- Inicio Estructura do While --");
        do {
            System.out.println(x);
            x++;
        } while (x <= 10);
        System.out.println("-- Fin Estructura do While --");
        System.out.println(x);

        // Estructura for
        System.out.println("-- Inicio Estructura For --");
        for (int a = 1; a <= 10; a++) {
            System.out.println(a);
        }
        System.out.println("-- Fin Estructura For --");
        // System.out.println(a); //error la variable esta fuera de alcance(scoped)

        // Recorrido con for usando una variable global
        System.out.println("-- Inicio Estructura For --");
        for (x = 1; x <= 10; x++) {
            System.out.println(x);
        }
        System.out.println("-- Fin Estructura For --");
        System.out.println(x);
        System.out.println("------------------------");
        for (x++; x <= 20; x++) {
            System.out.println(x);
        }
        System.out.println("------------------------");
        for (; x <= 30; x++) {
            System.out.println(x);
        }

        // Recorrido con dos o más variables de control
        for (int r = 1, s = 1; r <= 5 || s <= 10; r++, s++) {
            System.out.println(r + " " + s);
        }

        for (int r = 1, s = 1; r <= 5 && s <= 10; r++, s++) {
            System.out.println(r + " " + s);
        }

        // Sentencias break y continue (for while doWhile)
        for (int a = 1; a <= 30; a++) {
            if (a == 20)
                break; // rompe el ciclo
            if (a == 10 || a == 15)
                continue; // avanza un ciclo
            System.out.println(a);
        }

        // Omisión de parametros
        x = 1;
        for (;;) {
            System.out.println(x);
            x++;
            if (x > 10)
                break;
        }

        // for anidado
        int cont = 1;
        for (int r = 1; r <= 10; r++) {
            for (int s = 1; s <= 10; s++) {
                for (int y = 1; y <= 10; y++) {
                    System.out.println(r + " " + s + " " + y + " " + cont++);
                }
            }
        }


        DecimalFormat df=new DecimalFormat("00");
        //Horas del día
        for(int hora=0; hora<24; hora++){
            for(int minuto=0; minuto<60; minuto++){
                for(int segundo=0; segundo<60; segundo++){
                    System.out.println(df.format(hora)+":"+df.format(minuto)+":"+df.format(segundo));
                    //try{ Thread.sleep(1000); }catch(Exception e){} //delay 1s
                }
            }
        }

        LocalTime lt;
        // while(true){
        //     lt=LocalTime.now();
        //     System.out.println(
        //                         df.format(lt.getHour())+":"+
        //                         df.format(lt.getMinute())+":"+
        //                         df.format(lt.getSecond())
        //                     );
        //     try{ Thread.sleep(1000); }catch(Exception e){} //delay 1s
        // }

        //Loop infito
        // for(int a=0; true; a++){
        //     System.out.println(a);
        // }
        
        //Loop infito
        // for(int a=0; ; a++){
        //     System.out.println(a);
        // }

        //Loop infito
        // for(int a=0; a<=10 || true; a++){
        //     System.out.println(a);
        // }

        //Loop infito
        // for(int a=0; a<=10 || a>=1; a++){
        //     System.out.println(a);
        // }

        //Loop infito
        // for(int a=1; a<=10; ){
        //     System.out.println(a);
        // }

        //Loop infito
        // for(int a=1; a<=10; a++){
        //     System.out.println(a--);
        // }

        // Loop infito
        // int b=2;
        // for(int a=b; b<=10; a++){
        //     System.out.println(a);
        // }

        // Loop infito
        // int b=2;
        // for(int a=b; a<=10; b++){
        //     System.out.println(a);
        // }



    }
}