import java.text.DecimalFormat;
import java.util.Arrays;

public class Clase13 {
    public static void main(String[] args) {
        // Vectores - Arreglos

        // Declaración de vector o arreglo
        int[] numeros = new int[4];
        String[] nombres = new String[4];

        numeros[0] = 1;
        nombres[0] = "Juan";
        numeros[1] = 2;
        nombres[1] = "Laura";
        numeros[2] = 3;
        nombres[2] = "Jose";
        numeros[3] = 4;
        nombres[3] = "Claudia";
        // numeros[4]=5; //Error fuera de rango
        // nombres[4]="Mirta"; //Error fuera de rango
        // La primer posición de un vector tiene indice 0
        // La ultima posición tiene como indice el grado -1

        /*
         * numeros nombres indice
         * 1 Juan 0
         * 2 Laura 1
         * 3 Jose 2
         * 4 Claudia 3
         */

        System.out.println(numeros[2] + ", " + nombres[2]);

        // recorrido de los vectores
        System.out.println("**********************************");
        for (int a = 0; a < 4; a++) {
            System.out.println(numeros[a] + ", " + nombres[a]);
        }

        // Método length
        System.out.println("Longitud vector numeros: " + numeros.length);

        // recorrido usando length
        for (int a = 0; a < numeros.length; a++) {
            System.out.println(numeros[a] + ", " + nombres[a]);
        }

        System.out.println("**********************************");
        // recorrido inverso
        for (int a = numeros.length - 1; a >= 0; a--) {
            System.out.println(numeros[a] + ", " + nombres[a]);
        }

        System.out.println("**********************************");
        // recorrido usando while
        int b = 0;
        while (b < numeros.length) {
            System.out.println(numeros[b] + ", " + nombres[b]);
            b++;
        }

        // Declaración abreviada
        int[] vector = { 10, 25, 13, 14, 26, 10, 23, 29, 38, 39, 65, 10, 8, 17 };
        System.out.println("Longitud vector vector: " + vector.length);
        for (int a = 0; a < vector.length; a++) {
            System.out.print(vector[a] + ", ");
        }
        System.out.println();

        // Totalizar un vector
        // Promediar un vector
        int total = 0;
        for (int a = 0; a < vector.length; a++) {
            total += vector[a];
        }
        System.out.println("Total: " + total);
        System.out.println("Promedio: " + (total / vector.length));
        System.out.println("Promedio: " + ((float) total / vector.length));
        System.out.println("Promedio: " + ((double) total / vector.length));
        System.out.println("Promedio: " +
                new DecimalFormat(".00")
                        .format((float) total / vector.length));

        // Calculo de valor máximo y el valor mínimo
        // int[] vector={10, 25, 13, 14, 26, 10, 23, 29, 38, 39, 65, 10, 8, 17};
        int min = vector[0];
        int max = vector[0];
        for (int a = 0; a < vector.length; a++) {
            if (vector[a] < min)
                min = vector[a];
            if (vector[a] > max)
                max = vector[a];
        }
        System.out.println("Valor mínimo: " + min);
        System.out.println("Valor máximo: " + max);

        // Contar cantidad de números pares
        // Contar cantidad de números impares
        // Contar cantidad de veces que se repite el nro 10
        int cantPares = 0, cantImpares = 0, cant10 = 0;
        for (int a = 0; a < vector.length; a++) {
            if (vector[a] % 2 == 0)
                cantPares++;
            else
                cantImpares++;
            if (vector[a] == 10)
                cant10++;
        }
        System.out.println("Cantidad de números pares: " + cantPares);
        System.out.println("Cantidad de números impares: " + cantImpares);
        System.out.println("Cantidad de veces 10: " + cant10);

        // ordenar vector
        for (int a = 0; a < vector.length; a++) {
            System.out.print(vector[a] + ", ");
        }
        System.out.println();

        Arrays.sort(vector);

        for (int a = 0; a < vector.length; a++) {
            System.out.print(vector[a] + ", ");
        }
        System.out.println();
        
        for (int a = vector.length-1; a >=0; a--) {
            System.out.print(vector[a] + ", ");
        }
        System.out.println();

        // copiar vectores
        int[] pares={2, 4, 6, 8, 10};
        int[] impares=new int[pares.length];
        int[] pares2=new int[pares.length];
        /*
         *      pares               impares             pares2
         *          2                   _1__            _2__
         *          4                   _3__            _4__
         *          6                   _5__            _6__
         *          8                   _7__            _8__
         *         10                   _9__            _10_
         * 
         */

        for(int a=0; a<pares.length; a++){
            impares[a]=pares[a]-1;
        }

        for(int a=0; a<pares.length; a++){
            System.out.println(impares[a]+", "+pares[a]);
        }

        // Copiar vectores usando System.arraycopy()
        System.arraycopy(pares, 0, pares2, 0, pares.length);
        for(int a=0; a<pares.length; a++){
            System.out.println(pares[a]+", "+pares2[a]);
        }

        // vectors args
        System.out.println("Longitud Vector args: "+args.length);
        for(int a=0; a<args.length; a++) System.out.println(args[a]);


        //TODO Ejemplos de uso de vector args

    }
}
