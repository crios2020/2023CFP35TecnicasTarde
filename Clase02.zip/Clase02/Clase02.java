public class Clase02 {

    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";
    public static final String ANSI_RESET = "\u001B[0m";

    public static void main(String[] args) {

        // Clase 02
        System.out.println(ANSI_GREEN + "Clase 2!!");

        // Variables enteras
        int in = 2;
        System.out.println(in);
        System.out.println("Variable in=" + in);

        // Variables String
        String p = "perro";
        String l = "ladra";
        System.out.println(p + l);
        System.out.println(p + " " + l);
        System.out.println(p + " que " + l);

        // variables char Unicode 2 bytes
        char ch = 66;
        System.out.println(ch);
        ch = 'f';
        System.out.println(ch);
        ch -= 32; // restando 32 a la variable
        System.out.println(ch);
        ch = 3118;
        System.out.println(ch);

        // variables float 32 bit
        float fl = 6.89f;
        System.out.println(fl);

        // variables double 64 bit
        double dl = 6.89;
        System.out.println(dl);

        fl = 10;
        dl = 10;

        System.out.println(fl / 3);
        System.out.println(dl / 3);

        fl = 100;
        dl = 100;

        System.out.println(fl / 3);
        System.out.println(dl / 3);

        fl = 1000;
        dl = 1000;

        System.out.println(fl / 3);
        System.out.println(dl / 3);

        // variables boolean 1 byte (8 bits)
        boolean bo = true; // 1
        System.out.println(bo);
        bo = false; // 0
        System.out.println(false);

        // Operador de asignación =
        System.out.println("Operador de asignación");
        int nro1 = 5;
        int nro2 = 7;

        System.out.println(nro1);
        System.out.println(nro2);

        nro1 = nro2;
        // <----

        System.out.println(nro1);
        System.out.println(nro2);

        // Operadores Incrementales
        System.out.println("Operadores Incrementales");

        // sumar 1 a la variable ++
        nro1++; // nro1=nro1+1;
        System.out.println(nro1);

        // restar 1 a la variable --
        nro1--; // nro1=nro1-1;
        System.out.println(nro1);

        // sumar 5 a la variable +=
        nro1+=5; // nro1=nro1+5;
        System.out.println(nro1);

        // restar 5 a la variable -=
        nro1-=5; // nro1=nro1-5;
        System.out.println(nro1);

        // multiplicar por 5 la variable    *=
        nro1*=5; // nro1=nro1*5;
        System.out.println(nro1);

        // dividir por 5 la variable    /=
        nro1/=5; // nro1=nro1/5;
        System.out.println(nro1);

        //Preecedencia y procedencia de operadores binarios -- ++
        System.out.println(nro1);
        System.out.println(nro1++);
        System.out.println(nro1);
        System.out.println(++nro1);

        //Constantes
        System.out.println("Constantes");
        //final double PI=3.14;
        final double PI=Math.PI;

        //PI=4;         //Error no se puede cambiar el valor de una cte
        //PI++;
        System.out.println(PI);

        //Ingreso de datos por consola
        System.out.print("Ingrese su nombre: ");
        String nombre=new java.util.Scanner(System.in).nextLine();
        System.out.println("Hola "+nombre);


        /*
         * Desafio:
         *          - Crear la clase Triangulo, ingresar por consola base y altura y 
         *          luego calcular el perímetro y superficie de la figura.
         * 
         *          - Crear la clase Circulo, ingresar por consola el radio y
         *          luego calcular el perímetro y superficie de la figura.
         * 
         */

         //TODO Operadores Relaciones
         //TODO Operadores Logicos
         //TODO Utilidades DecimalFormat LocalDateTime String
         
    }
}