public class Rectangulo {
    public static void main(String[] args) {
        
        System.out.print("Ingrese lado1 del rectángulo: ");
        int lado1=new java.util.Scanner(System.in).nextInt();
        System.out.print("Ingrese el lado2 del rectágulo: ");
        int lado2=new java.util.Scanner(System.in).nextInt();

        int perimetro=(lado1+lado2)*2;
        int superficie=lado1*lado2;

        System.out.println("El perimetro es "+perimetro);
        System.out.println("La superficie es "+superficie);

        
    }
}
